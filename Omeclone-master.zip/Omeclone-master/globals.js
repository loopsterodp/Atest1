// All globals here.
global.onlineUsers = [];
global.availableUsers = [];
global.rooms = [];
global.queue = [];
